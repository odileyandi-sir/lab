	</html> 

ListCookies.jsp

<html>
<body>
<%
String str1 = request.getParameter("name");
String str2 = request.getParameter("age");
String str3 = request.getParameter("add");
String str4 = request.getParameter("list");
if(str3 != null){
Cookie c1 = new Cookie(str1, str2);
response.addCookie(c1);
}
else if(str4 != null){
Cookie clientCookies[] = request.getCookies();
for( int i = 0; i < clientCookies.length; i++){
out.print("<b>" + clientCookies[i].getName() + " : " + clientCookies[i].getValue() + "</b><br>");
}
}
%>
</body>
</html>


b) Write JSP for a web application that takes name and age from an HTML page. If the age is less than 18, it should send a page with “Hello <name>, you are not authorized to visit this site” message, where <name> should be replaced with the entered name. Otherwise it should send “Welcome <name> to this site” message.


Age.html
	<html> 
	<body> 
	<form action="age.jsp"> 
	Username:<input type="text" name="username"> <br> 
	Age:<input type="text" name="age" > <br> 
	<input type="submit" name="submit"> 
	</form> 
	</body> 
	</html> 
	
	

Age.jsp

<%
	String name=request.getParameter("username");  
	int age=Integer.parseInt(request.getParameter("age"));  
if(age < 18){
		out.println(“Hello ”+name+ “ you are not authorized to visit this site” );  
	} else{  
        		out.println("Welcome " + name + “ to this site”);  
        	}  
%>

10. A) Write a PHP for User validation web application, where the user submits a login name and password to the server. The name and password are checked against the data already available in Database and if the data matches, a successful login page is returned. Otherwise a failure message is shown to the user.

Index.html

	<html> 
	<body> 
	<div> 
	<form action="login.php" method="POST"> 
	<p>LOGIN FORM</p><br /> 
	<p>USERNAME:</p> 
	<input type="text" name="uname" ><br /> 
	<p>PASSWORD:</p> 
	<input type="password" name="pass" ><br /> 
	<input type="submit" name="submit" value="Login"><br /> 
	</form> 
	</div> 
	</body> 
	</html> 
	


Login.php

<?php

$uname=$_POST["uname"];
$pass=$_POST["pass"];
$con=mysqli_connect("localhost","root","","test1");
if(!$con){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  

$query="select * from users where USERNAME='$uname' and PASSWORD='$pass'";
$records=mysqli_query($con,$query);
if(mysqli_num_rows($records)>=1)
{
header("Location: success.html");
}
else{
echo "wrong";
}
?>

b) Write a PHP for A simple calculator web application that takes two numbers and an operator (+,-, /,*and %) from an HTML page and returns the result page with the operation performed on the operands.


Calc.html

	<html> 
	<body> 
	<form action="calc.php" method="POST" > 
	<p>Enter First Number:</p> 
	<input type="text" name="op1"/><br /> 
	<p>Enter Second Number:</p> 
	<input type="text" name="op2"/><br /> 
	<p>Enter Operator:</p> 
	<input type="text" name="operator"/><br /> 
	<input type="submit" value="Submit" name="submit" /> 
	</form> 
	
	</body> 
	</html> 
	
	

Calc.php

<?php

if(isset($_POST["submit"]) && isset($_POST["op1"]) && isset($_POST["op2"]) && isset($_POST["operator"])){
$op1=(int)$_POST["op1"];
$op2=(int)$_POST["op2"];
$operator=$_POST["operator"];
if($operator=="+"){
echo "Addition of ".$op1." and ".$op2." is ".($op1+$op2);
}else if($operator=="-"){
echo "Subtraction of ".$op1." and ".$op2." is ".($op1-$op2);
}else if($operator=="*"){
echo "Multiplication of ".$op1." and ".$op2." is ".($op1*$op2);
}else if($operator=="/"){
if($op2!=0){
echo "Division of ".$op1." and ".$op2." is ".($op1/$op2);
}else{
echo "second number cannot be zero";
}
}else if($operator=="%"){
echo "Remainder of ".$op1." and ".$op2." is ".($op1%$op2);
}
}

?>


11) Write PHP Code Validate the following fields of registration page.
i)	Name (it should contains alphabets and length at least 6 characters)
ii)	 Password(it should not be less than 6 characters)
iii)	Email id (it should not contains any invalid character must follow the standard pattern name@domain.com)
iv)	Phone number (it should contain 10 digits only)


Validation.php

<center><h2>Validation Form</h2>
<form method="get">

Name: <input type="text" name="uname"><br>

Password: <input type="text" name="pass"><br>

Email ID: <input type="text" name="email"><br>

Phone Number: <input type="text" name="phone"><br>

<input type="submit" name="submit" value="Validate">

</form>


<?php

if(isset($_POST['submit'])) {
	
$uname = $_POST['uname'];
	
$pass = $_POST['pass'];
	
$email = $_POST['email'];
	
$phone = $_POST['phone'];
	
$flag = 1;
	
if(!$uname) echo "Name not entered!<br>";
	
else {
		
if(ctype_alpha($uname)==0) { 
echo "Name contains numeric characters<br>"; 
$flag=0; 
}
		
else if(strlen($uname)<6) { 
echo "Name is less than 6 characters<br>";
$flag=0; 
}
	
}
if(!$pass) 
echo "Password not entered!<br>";
	
else {
		
if(strlen($pass)<6) { 
echo "Password is less than 6 characters<br>";
$flag=0; 
}
	
}
	
if(!$email) 
echo "Email not entered!<br>";
	
else {
		
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
echo "Email address is Incorrect<br>";
$flag=0; 
}
	
}
	
if(!$phone) 
echo "Phone number not entered!<br>";
	
else {
		
if(ctype_digit($phone)==0) { 
echo "Phone Number cannot contain alphabets<br>";
$flag=0; 
}
		
else if(strlen($phone)!=10) { 
echo "Phone Number is not 10 digits long<br>";
$flag=0; 
}
}
	
if($flag) 
echo "All fields are validated!";

}

?>

</center>

12) A web application for implementation using PHP.
The user is first served login page which takes user’s name and password. After submitting the details the server checks these values against the data from a database and takes the following decisions
If name and password match serves a welcome page with user’s full name
If name matches and password doesn’t match, then server ‘password mismatch’ page
If name is not found in the full name, it stores, the login name, password and full name in the database.(hint: Use session for storing the submitted login name and password)


LoginValidation.php

<?php

$con = mysqli_connect("localhost","root","Gcet@123","test");

if(!$con) 
	die(mysqli_error($con));

if(isset($_POST['submit'])) {
	
	$uname = $_POST['user'];
	
	$pwd = $_POST['pass'];
	
	if($uname and $pwd) {
		
		$res = mysqli_query($con,"select * from users where username='$uname' and password = '$pwd'");
		
		if(mysqli_num_rows($res)>0) {
			
			$row = mysqli_fetch_assoc($res);
			
			echo '<h1>Welcome '.$row['name'].'</h1>';

			exit;

		}

		$res = mysqli_query($con,"select * from users where username='$uname'");
			if(mysqli_num_rows($res)>0) {

			echo '<center><h3>Password Mismatch!<h3></center>';

		}

		else {
	
		echo '<center>User is not available.<h2>Registration Form</h2><form method="post">Full Name: <input type="text" name="name"><br>Username: <input type="text" name="user"><br>Password: <input type="password" name="pass"><br>Retype Password: <input type="password" name="pass1"><br><input type="submit" name="register" value="Register"></form></center>';

		exit;

		}

	}

}
if(isset($_POST['register'])) {
	$uname = $_POST['user'];
	$name = $_POST['name'];
	$pwd = $_POST['pass'];
	$pwd1 = $_POST['pass1'];
	if($uname and $name and $pwd and $pwd1)
	if(strcmp($pwd,$pwd1)!=0) echo "Passwords are not matched!";
	else {
		$res = mysqli_query($con,"insert into users values('$uname','$pwd','$name')");
		echo 'Inserted Successfully';
	}
}
?>
<center><h2>Sign In</h2><form method="post">
Username: <input type="text" name="user"><br>
Password: <input type="password" name="pass"><br>
<input type="submit" name="submit" value="Login">
</form></center>
	
	


